# BBS 1.7.10 Forge port workspace (starter)

Target: Minecraft 1.7.10 / Forge 10.13.4.1614.

## Included
- `reference/bbs-fs-2.8-1.12.2-alpha.1.jar`: the uploaded 1.12.2 compiled mod, retained as a reference.
- `build.gradle` and `settings.gradle`: legacy ForgeGradle 1.2 project configuration.
- `.github/workflows/build.yml`: GitHub Actions workflow for a Java 8 / Gradle 2.14.1 build.
- `src/main/java` and `src/main/resources`: destination folders for the ported source and assets.

## Important status
This is a build-ready *starter workspace*, not a completed 1.7.10 conversion. The uploaded JAR contains compiled `.class` files rather than the original Java source. The existing 1.12.2 classes cannot simply be relabeled as 1.7.10; their Minecraft/Forge calls and the coremod loading plugin need to be ported. No converted source has been added yet, so the workflow will not produce a functional mod JAR until that port is implemented.

## GitHub use
Upload the contents of this ZIP to the repository root (including the hidden `.github` folder). GitHub Actions runs on push or from the Actions tab via `workflow_dispatch`.
